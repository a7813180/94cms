<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 23
ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 25
ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 28
ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 30
ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 32
ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 35
ERROR - 2014-12-10 00:15:08 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 39
ERROR - 2014-12-10 00:15:29 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 23
ERROR - 2014-12-10 00:15:29 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 25
ERROR - 2014-12-10 00:15:44 --> Severity: Notice  --> Undefined variable: u_info G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 26
ERROR - 2014-12-10 00:17:45 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_pwd.html 27
ERROR - 2014-12-10 00:44:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-10 00:44:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-10 00:44:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-10 00:44:47 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 00:44:48 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 00:44:50 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 00:44:51 --> 404 Page Not Found --> mydata/js
ERROR - 2014-12-10 00:44:57 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:08:11 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 15:19:03 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 15:21:20 --> 404 Page Not Found --> admins/site.htm
ERROR - 2014-12-10 15:21:22 --> 404 Page Not Found --> admins/home.htm
ERROR - 2014-12-10 15:21:25 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 15:21:27 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:21:27 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:21:47 --> 404 Page Not Found --> admins/site.html
ERROR - 2014-12-10 15:22:23 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:22:32 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 15:22:43 --> 404 Page Not Found --> admins/site.do
ERROR - 2014-12-10 15:23:15 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 15:23:23 --> 404 Page Not Found --> admins/siteshtml
ERROR - 2014-12-10 15:24:13 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 15:24:15 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-10 15:24:30 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:36:26 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:26 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:29 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:29 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:30 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:32 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:32 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:33 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:36:33 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:37:05 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:41:04 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-10 15:41:04 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-10 15:41:04 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-10 15:41:27 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:41:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:41:38 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:41:41 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:43:28 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:43:48 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-10 15:43:48 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-10 15:43:48 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-10 15:43:52 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-10 15:43:52 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-10 15:43:52 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-10 15:43:52 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:43:55 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:46:01 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:46:31 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 15:55:45 --> 404 Page Not Found --> show/dow
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:26:37 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:26:42 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 17:26:50 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:27:46 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:29:04 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 17:44:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-10 17:44:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-10 17:44:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-10 17:44:09 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 17:45:22 --> Query error: Unknown column 'dowurl' in 'field list'
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:18:31 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:19:04 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:21:01 --> Severity: Notice  --> Undefined property: Show::$session G:\AppServ\www\sihai5\app\controllers\show.php 179
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:25:29 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 18:25:34 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-10 18:25:38 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-10 18:36:40 --> Severity: Warning  --> stat() [<a href='function.stat'>function.stat</a>]: stat failed for http://94cms.host.tcncn.com/uploads/file/12-10-14182072465263.rar G:\AppServ\www\sihai5\app\controllers\show.php 183
ERROR - 2014-12-10 18:36:41 --> Severity: Warning  --> stat() [<a href='function.stat'>function.stat</a>]: stat failed for http://94cms.host.tcncn.com/uploads/file/12-10-14182072465263.rar G:\AppServ\www\sihai5\app\controllers\show.php 183
ERROR - 2014-12-10 18:36:42 --> Severity: Warning  --> stat() [<a href='function.stat'>function.stat</a>]: stat failed for http://94cms.host.tcncn.com/uploads/file/12-10-14182072465263.rar G:\AppServ\www\sihai5\app\controllers\show.php 183
ERROR - 2014-12-10 18:46:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/sihai4/uploads/file/11-17-14162387632244.rar) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\controllers\show.php 182
ERROR - 2014-12-10 18:48:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/sihai4/uploads/file/11-17-14162387632244.rar) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\controllers\show.php 182
ERROR - 2014-12-10 18:48:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/sihai4/uploads/file/11-17-14162387632244.rar) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\controllers\show.php 182
ERROR - 2014-12-10 19:57:59 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 19:58:00 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 19:58:05 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 141
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 19:58:23 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-10 19:59:19 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\controllers\show.php 187
ERROR - 2014-12-10 21:42:17 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 21:42:19 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-10 21:42:27 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 21:45:26 --> Severity: Notice  --> Undefined variable: reg_code G:\AppServ\www\sihai5\app\modules\member\views\index_deposit.html 37
ERROR - 2014-12-10 21:46:13 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\views\index_deposit.html 23
ERROR - 2014-12-10 21:46:13 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_deposit.html 25
ERROR - 2014-12-10 22:03:56 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-10 22:03:56 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-10 22:03:56 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-10 22:03:58 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-10 22:04:12 --> Severity: Notice  --> Undefined variable: money G:\AppServ\www\sihai5\app\controllers\show.php 187
ERROR - 2014-12-10 22:13:30 --> Query error: Unknown column 'dows' in 'field list'
ERROR - 2014-12-10 23:02:02 --> Severity: Notice  --> Undefined variable: total_rows G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 98
ERROR - 2014-12-10 23:02:02 --> Severity: Notice  --> Undefined variable: perPage G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 99
ERROR - 2014-12-10 23:04:26 --> 404 Page Not Found --> home/js
ERROR - 2014-12-10 23:31:38 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\views\index_jifen.html 24
ERROR - 2014-12-10 23:31:38 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_jifen.html 26
ERROR - 2014-12-10 23:32:31 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_jifen.html 26
ERROR - 2014-12-10 23:32:40 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_jifen.html 26
ERROR - 2014-12-10 23:50:17 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 137
ERROR - 2014-12-10 23:50:41 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 137
ERROR - 2014-12-10 23:51:26 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 137
ERROR - 2014-12-10 23:51:59 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 137
ERROR - 2014-12-10 23:52:04 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 137
ERROR - 2014-12-10 23:52:47 --> Severity: Notice  --> Undefined index:  moner G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 137
ERROR - 2014-12-10 23:56:30 --> Query error: Unknown column 'jinfenbili' in 'field list'
ERROR - 2014-12-10 23:56:39 --> Query error: Unknown column 'jifenbili' in 'field list'
ERROR - 2014-12-10 23:56:51 --> Query error: Unknown column 'jifenbili' in 'field list'
