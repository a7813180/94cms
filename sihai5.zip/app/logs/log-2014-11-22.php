<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-22 23:34:19 --> Unable to select database: 94cms5
