<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-09 15:33:16 --> 404 Page Not Found --> home/js
ERROR - 2014-12-09 15:40:25 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\modules\member\views\index_setprofile.html 5
ERROR - 2014-12-09 16:19:41 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-09 16:19:41 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-09 16:31:43 --> Severity: Notice  --> Undefined variable: login_code G:\AppServ\www\sihai5\app\modules\member\views\index_login.html 73
ERROR - 2014-12-09 16:31:45 --> Severity: Notice  --> Undefined variable: login_code G:\AppServ\www\sihai5\app\modules\member\views\index_login.html 73
ERROR - 2014-12-09 16:41:45 --> Severity: Notice  --> Undefined index:  login_code G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 88
ERROR - 2014-12-09 21:43:42 --> 404 Page Not Found --> home/js
ERROR - 2014-12-09 23:42:14 --> 404 Page Not Found --> home/js
ERROR - 2014-12-09 23:43:40 --> Severity: Notice  --> Undefined index:  code G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 54
ERROR - 2014-12-09 23:44:51 --> Severity: Notice  --> Undefined index:  code G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 54
ERROR - 2014-12-09 23:46:17 --> Severity: Notice  --> Undefined index:  code G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 99
ERROR - 2014-12-09 23:53:41 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:53:41 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:53:56 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:53:56 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:53:57 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:53:57 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:19 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:19 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:23 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:23 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:24 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:24 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:35 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:35 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:36 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:36 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:37 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:37 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:38 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:38 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:38 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:38 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:39 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:39 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:39 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:39 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:39 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:39 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:39 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:39 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:39 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:39 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:39 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:39 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:54 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:54 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
ERROR - 2014-12-09 23:55:59 --> Severity: Warning  --> Missing argument 1 for Member_Admin_home_module::del() G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 45
ERROR - 2014-12-09 23:55:59 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 46
