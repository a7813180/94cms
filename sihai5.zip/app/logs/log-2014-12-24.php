<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-24 12:45:23 --> 404 Page Not Found --> home/js
ERROR - 2014-12-24 12:48:28 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:48:35 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:48:39 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:48:50 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:50:28 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:50:29 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:50:30 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:50:58 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 12:51:02 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-24 12:51:02 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-24 13:02:56 --> 404 Page Not Found --> home/js
ERROR - 2014-12-24 13:03:48 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 13:03:50 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 13:03:51 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 13:03:53 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 13:03:56 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 13:11:27 --> 404 Page Not Found --> html/index
ERROR - 2014-12-24 13:14:16 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 109
ERROR - 2014-12-24 13:14:16 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 109
ERROR - 2014-12-24 13:14:16 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 109
ERROR - 2014-12-24 13:14:16 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 109
ERROR - 2014-12-24 13:16:40 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\boze\list_diy.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 107
ERROR - 2014-12-24 13:16:40 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 32
ERROR - 2014-12-24 13:17:10 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\boze\list_diy.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 106
ERROR - 2014-12-24 13:17:10 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-24 13:17:52 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 111
ERROR - 2014-12-24 13:17:52 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 111
ERROR - 2014-12-24 13:17:52 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 111
ERROR - 2014-12-24 13:17:52 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 111
ERROR - 2014-12-24 13:19:08 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\boze\list_diy.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 106
ERROR - 2014-12-24 13:19:08 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-24 13:20:45 --> 404 Page Not Found --> html/%7BPUBLIC%7Dstyle
ERROR - 2014-12-24 13:20:45 --> 404 Page Not Found --> html/%7BPUBLIC%7Djs
ERROR - 2014-12-24 13:22:43 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-24 13:25:16 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 32
ERROR - 2014-12-24 13:25:31 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 115
ERROR - 2014-12-24 13:25:31 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 115
ERROR - 2014-12-24 13:25:32 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 115
ERROR - 2014-12-24 13:25:32 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 115
ERROR - 2014-12-24 13:26:49 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 115
ERROR - 2014-12-24 13:27:18 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 115
