<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-03 00:05:23 --> 404 Page Not Found --> home/js
ERROR - 2014-12-03 00:12:07 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-03 00:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-03 00:12:10 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-03 01:26:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\views\index\94cms_head.html.php 9
ERROR - 2014-12-03 01:26:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\views\index\94cms_head.html.php 9
ERROR - 2014-12-03 01:26:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\views\index\94cms_head.html.php 9
ERROR - 2014-12-03 01:26:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\views\index\94cms_head.html.php 9
ERROR - 2014-12-03 01:26:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\views\index\94cms_head.html.php 9
ERROR - 2014-12-03 01:26:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\views\index\94cms_head.html.php 9
ERROR - 2014-12-03 10:01:11 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\index\94cms_list_product.html.php 34
ERROR - 2014-12-03 10:01:11 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\index\94cms_list_product.html.php 34
ERROR - 2014-12-03 10:01:11 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\index\94cms_list_product.html.php 34
ERROR - 2014-12-03 10:01:11 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\index\94cms_list_product.html.php 34
ERROR - 2014-12-03 10:01:11 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\index\94cms_list_product.html.php 34
ERROR - 2014-12-03 10:01:11 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\index\94cms_list_product.html.php 34
ERROR - 2014-12-03 10:30:43 --> 404 Page Not Found --> home/js
ERROR - 2014-12-03 10:30:45 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-03 11:06:56 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-03 11:22:25 --> 404 Page Not Found --> home/js
ERROR - 2014-12-03 11:24:01 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-03 11:24:01 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-03 11:24:01 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-03 11:24:01 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-03 11:24:02 --> 404 Page Not Found --> admins/js
