<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-28 13:30:16 --> 404 Page Not Found --> home/js
ERROR - 2014-12-28 13:30:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:30:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 13:36:52 --> 404 Page Not Found --> html/index
ERROR - 2014-12-28 13:37:22 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-28 13:37:22 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-28 13:37:22 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-28 13:37:23 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-28 13:37:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-28 13:37:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-28 13:37:30 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 13:37:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 13:37:35 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-28 13:37:41 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 13:37:41 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-28 13:37:47 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-28 15:34:46 --> 404 Page Not Found --> home/js
ERROR - 2014-12-28 15:35:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:32 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-28 15:35:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:35:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 15:37:57 --> 404 Page Not Found --> home/js
ERROR - 2014-12-28 20:38:51 --> 404 Page Not Found --> html/index
ERROR - 2014-12-28 20:49:43 --> 404 Page Not Found --> home/mysqls
ERROR - 2014-12-28 20:58:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 20:58:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:08:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\news\143.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-28 21:08:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-28 21:08:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 73
ERROR - 2014-12-28 21:10:02 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:10:02 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:11:14 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\news\1492.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-28 21:11:14 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-28 21:11:14 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 73
ERROR - 2014-12-28 21:22:37 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:38 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:38 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:40 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:22:40 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:23:31 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\content_list.html 212
ERROR - 2014-12-28 21:23:31 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_list.html 212
ERROR - 2014-12-28 21:24:05 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\content_list.html 212
ERROR - 2014-12-28 21:24:05 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_list.html 212
ERROR - 2014-12-28 21:24:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-28 21:24:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-28 21:24:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-28 21:24:23 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:24:23 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-28 21:31:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1915.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1916.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1917.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1918.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1919.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1920.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1921.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1922.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1923.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1924.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1925.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1926.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1927.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1928.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1929.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1930.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1931.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1932.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1933.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1934.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1935.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1936.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1937.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1938.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1939.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1940.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1941.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1942.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1943.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1944.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1945.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1946.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1947.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1948.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1949.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1950.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1951.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1952.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1953.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1954.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1955.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1956.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1957.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1958.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1959.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1960.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1961.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1962.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1963.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1964.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1965.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1966.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1967.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1968.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1969.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1970.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1971.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1972.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1973.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1974.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1975.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1976.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1977.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1978.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1979.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1980.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1981.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1982.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1983.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1984.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1985.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1986.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1987.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1988.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1989.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1990.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1991.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1992.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1993.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1994.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1995.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1996.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1997.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1998.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1999.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2000.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2001.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2002.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2003.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2004.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2005.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2006.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2007.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2008.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2009.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2010.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2011.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2012.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2013.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2014.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2015.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2016.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2017.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2018.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2019.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2020.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2021.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2022.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2023.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2024.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2025.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2026.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2027.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2028.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2029.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2030.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2031.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2032.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2033.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2034.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2035.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2036.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2037.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2038.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2039.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2040.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2041.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2042.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2043.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2044.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2045.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2046.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2047.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2048.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2049.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2050.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2051.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2052.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2053.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2054.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2055.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2056.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2057.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2058.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2059.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2060.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2061.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2062.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2063.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2064.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2065.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2066.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2067.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2068.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2069.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2070.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2071.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2072.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2073.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2074.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2075.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2076.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2077.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2078.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2079.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2080.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2081.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2082.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2083.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2084.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2085.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2086.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2087.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2088.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2089.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2090.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2091.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2092.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2093.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2094.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2095.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2096.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2097.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2098.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2099.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2100.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2101.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2102.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2103.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2104.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:31:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1915.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1916.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1917.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1918.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1919.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1920.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1921.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1922.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1923.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1924.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1925.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1926.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1927.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1928.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1929.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1930.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1931.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1932.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1933.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1934.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1935.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:40:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1936.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1937.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1938.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1939.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1940.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1941.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1942.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1943.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1944.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1945.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1946.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1947.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1948.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1949.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1950.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1951.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1952.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1953.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1954.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1955.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1956.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1957.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1958.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1959.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1960.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1961.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1962.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1963.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1964.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1965.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1966.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1967.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1968.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1969.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1970.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1971.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1972.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1973.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1974.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1975.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1976.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1977.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1978.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1979.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1980.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1981.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1982.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1983.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1984.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:06 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1985.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1986.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1987.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1988.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1989.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1990.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1991.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1992.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:07 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1993.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1994.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1995.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1996.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1997.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1998.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/1999.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:08 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2000.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2001.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2002.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2003.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2004.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2005.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2006.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2007.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2008.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2009.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2010.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2011.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2012.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2013.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2014.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2015.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2016.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2017.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2018.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2019.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2020.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2021.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2022.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2023.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2024.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2025.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2026.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2027.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2028.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2029.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2030.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2031.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2032.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2033.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2034.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2035.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2036.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2037.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2038.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2039.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2040.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2041.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2042.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2043.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2044.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2045.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2046.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2047.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2048.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2049.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2050.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2051.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2052.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2053.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2054.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2055.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2056.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2057.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2058.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2059.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2060.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2061.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2062.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2063.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2064.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2065.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2066.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2067.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2068.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2069.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2070.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2071.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2072.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2073.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2074.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2075.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2076.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2077.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2078.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2079.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2080.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2081.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2082.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2083.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2084.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2085.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2086.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2087.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2088.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2089.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2090.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2091.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2092.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2093.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2094.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2095.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2096.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2097.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2098.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2099.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2100.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2101.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2102.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2103.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/2104.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 21:41:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-28 23:14:50 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\content_list.html 212
ERROR - 2014-12-28 23:14:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_list.html 212
ERROR - 2014-12-28 23:43:09 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\libraries\thtml.php 10
