<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-21 00:08:47 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 00:08:48 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-21 00:10:16 --> Severity: Notice  --> Undefined variable: datas G:\AppServ\www\sihai5\app\controllers\admins\html.php 18
ERROR - 2014-12-21 00:10:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\vip_1\list_duwnload.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 104
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/15.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\vip_1\list_duwnload.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 104
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/16.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\vip_1\list_duwnload.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 104
ERROR - 2014-12-21 00:10:40 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-21 00:10:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/17.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/18.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:48 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\vip_1\list_duwnload.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 104
ERROR - 2014-12-21 00:10:48 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-21 00:10:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/15.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:48 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\vip_1\list_duwnload.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 104
ERROR - 2014-12-21 00:10:48 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-21 00:10:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/16.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:49 --> Severity: Warning  --> file_get_contents(G:\AppServ\www\sihai5\template\vip_1\list_duwnload.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 104
ERROR - 2014-12-21 00:10:49 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-21 00:10:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/17.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:10:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/cate/index/18.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 53
ERROR - 2014-12-21 00:13:19 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 00:15:11 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 00:15:28 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 00:16:23 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-21 00:18:07 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-21 00:18:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-21 00:18:09 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-21 00:22:07 --> 404 Page Not Found --> admins/home.shtml
ERROR - 2014-12-21 00:22:10 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 00:25:36 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 00:25:39 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-21 21:23:22 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 21:23:27 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 21:23:41 --> 404 Page Not Found --> home/js
ERROR - 2014-12-21 22:28:26 --> 404 Page Not Found --> home/js
