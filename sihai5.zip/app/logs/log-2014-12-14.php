<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-14 00:08:17 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:17 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:17 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:17 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:37 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> Missing argument 2 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> Missing argument 3 for tHtml::schtml(), called in G:\AppServ\www\sihai5\app\libraries\thtml.php on line 10 and defined G:\AppServ\www\sihai5\app\libraries\thtml.php 18
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: show G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 20
ERROR - 2014-12-14 00:08:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/Array.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:08:38 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-14 00:42:02 --> Severity: Notice  --> Undefined variable: tablename G:\AppServ\www\sihai5\app\libraries\thtml.php 24
ERROR - 2014-12-14 00:50:51 --> Severity: Notice  --> Undefined variable: tb G:\AppServ\www\sihai5\app\libraries\thtml.php 27
ERROR - 2014-12-14 00:50:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `94_news`.`status` =  0
AND `94_`.`cid` IN ('6', '7', '8', '9')' at line 2
ERROR - 2014-12-14 00:50:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at G:\AppServ\www\sihai5\system\core\Exceptions.php:185) G:\AppServ\www\sihai5\system\core\Common.php 442
ERROR - 2014-12-14 00:51:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `94_news`.`status` =  0
AND `94_news`.`cid` IN ('6', '7', '8', '9')' at line 2
ERROR - 2014-12-14 00:52:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `94_news`.`status` =  0
AND `94_news`.`id` IN ('6', '7', '8', '9')' at line 2
ERROR - 2014-12-14 00:52:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `status` =  0
AND `id` IN ('6', '7', '8', '9')' at line 2
ERROR - 2014-12-14 00:52:59 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\libraries\thtml.php 21
ERROR - 2014-12-14 00:52:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `status` =  0
AND `id` IN ('6', '7', '8', '9', NULL)' at line 2
ERROR - 2014-12-14 00:52:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at G:\AppServ\www\sihai5\system\core\Exceptions.php:185) G:\AppServ\www\sihai5\system\core\Common.php 442
ERROR - 2014-12-14 00:53:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `status` =  0
AND `id` IN ('6', '7', '8', '9', '5')' at line 2
ERROR - 2014-12-14 00:53:35 --> Severity: Notice  --> Undefined index:  num G:\AppServ\www\sihai5\app\libraries\thtml.php 30
ERROR - 2014-12-14 00:53:35 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\libraries\thtml.php 30
ERROR - 2014-12-14 12:27:27 --> Severity: Warning  --> file_get_contents(http://ip.taobao.com/service/getIpInfo.php?ip=127.0.0.1) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.1 502 Bad Gateway
 G:\AppServ\www\sihai5\system\core\Common.php 596
ERROR - 2014-12-14 12:37:50 --> 404 Page Not Found --> home/js
ERROR - 2014-12-14 12:57:17 --> 404 Page Not Found --> home/js
