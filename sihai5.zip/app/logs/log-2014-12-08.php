<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-08 00:00:52 --> Severity: Notice  --> Undefined property: Member_login_module::$validation G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 36
ERROR - 2014-12-08 00:01:03 --> Severity: Warning  --> Missing argument 1 for CI_Form_validation::set_message(), called in G:\AppServ\www\sihai5\app\modules\member\controllers\login.php on line 37 and defined G:\AppServ\www\sihai5\system\libraries\Form_validation.php 165
ERROR - 2014-12-08 00:01:03 --> Severity: Notice  --> Undefined variable: lang G:\AppServ\www\sihai5\system\libraries\Form_validation.php 167
ERROR - 2014-12-08 00:01:03 --> Severity: Notice  --> Undefined variable: lang G:\AppServ\www\sihai5\system\libraries\Form_validation.php 169
ERROR - 2014-12-08 00:01:03 --> Severity: 4096  --> Object of class CI_Form_validation could not be converted to string G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 37
ERROR - 2014-12-08 00:02:00 --> Severity: 4096  --> Object of class CI_Form_validation could not be converted to string G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 37
ERROR - 2014-12-08 00:02:10 --> Severity: 4096  --> Object of class CI_Form_validation could not be converted to string G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 37
ERROR - 2014-12-08 00:02:36 --> Severity: 4096  --> Object of class CI_Form_validation could not be converted to string G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 37
ERROR - 2014-12-08 00:02:44 --> Severity: 4096  --> Object of class CI_Form_validation could not be converted to string G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 37
ERROR - 2014-12-08 00:11:07 --> Severity: Warning  --> Missing argument 1 for CI_Form_validation::set_message(), called in G:\AppServ\www\sihai5\app\modules\member\controllers\login.php on line 38 and defined G:\AppServ\www\sihai5\system\libraries\Form_validation.php 165
ERROR - 2014-12-08 00:11:07 --> Severity: Notice  --> Undefined variable: lang G:\AppServ\www\sihai5\system\libraries\Form_validation.php 167
ERROR - 2014-12-08 00:11:07 --> Severity: Notice  --> Undefined variable: lang G:\AppServ\www\sihai5\system\libraries\Form_validation.php 169
ERROR - 2014-12-08 00:11:07 --> Severity: 4096  --> Object of class CI_Form_validation could not be converted to string G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 38
ERROR - 2014-12-08 13:10:45 --> Severity: Notice  --> Undefined property: CI_Form_validation::$run G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 87
ERROR - 2014-12-08 13:10:49 --> Severity: Notice  --> Undefined property: CI_Form_validation::$run G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 87
ERROR - 2014-12-08 15:56:20 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 15:56:27 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 15:56:39 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 15:56:45 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 15:56:52 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 15:57:05 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 15:57:52 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_search.html.php 14
ERROR - 2014-12-08 16:00:40 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_tag.html.php 14
ERROR - 2014-12-08 20:14:05 --> Severity: Notice  --> iconv() [<a href='function.iconv'>function.iconv</a>]: Detected an incomplete multibyte character in input string G:\AppServ\www\sihai5\system\core\Utf8.php 89
ERROR - 2014-12-08 21:28:47 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 16
ERROR - 2014-12-08 21:41:44 --> Severity: Notice  --> Use of undefined constant member - assumed 'member' G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 15
ERROR - 2014-12-08 21:41:44 --> Severity: Notice  --> Use of undefined constant home - assumed 'home' G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 15
ERROR - 2014-12-08 21:41:44 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 15
ERROR - 2014-12-08 21:41:44 --> Severity: Notice  --> Use of undefined constant setprofile - assumed 'setprofile' G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 15
ERROR - 2014-12-08 21:41:44 --> Severity: Warning  --> Division by zero G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 15
ERROR - 2014-12-08 21:55:17 --> Severity: Notice  --> Undefined property: Member_login_module::$session G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 99
ERROR - 2014-12-08 22:08:46 --> 404 Page Not Found --> home/js
ERROR - 2014-12-08 22:08:51 --> 404 Page Not Found --> home/js
ERROR - 2014-12-08 22:08:52 --> 404 Page Not Found --> home/js
ERROR - 2014-12-08 22:08:53 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-08 22:12:29 --> 404 Page Not Found --> home/js
ERROR - 2014-12-08 22:44:21 --> 404 Page Not Found --> home/js
ERROR - 2014-12-08 22:44:22 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-08 22:49:04 --> 404 Page Not Found --> home/js
ERROR - 2014-12-08 23:03:02 --> 404 Page Not Found --> home/js
