<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-01 15:11:10 --> 404 Page Not Found --> home/js
ERROR - 2014-12-01 15:15:26 --> 404 Page Not Found --> home/js
ERROR - 2014-12-01 15:15:28 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-01 15:15:50 --> 404 Page Not Found --> home/js
ERROR - 2014-12-01 15:18:30 --> 404 Page Not Found --> home/js
ERROR - 2014-12-01 15:18:32 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-01 15:18:36 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:18:38 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-01 15:18:38 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-01 15:18:38 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-01 15:18:39 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:19:19 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-01 15:19:19 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-01 15:19:19 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-01 15:19:22 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:19:26 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:19:26 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:19:27 --> 404 Page Not Found --> mydata/js
ERROR - 2014-12-01 15:19:30 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:19:32 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-01 15:25:54 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 212
ERROR - 2014-12-01 15:25:54 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 220
ERROR - 2014-12-01 15:25:54 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_add.html 166
