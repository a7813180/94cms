<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-05 13:52:31 --> 404 Page Not Found --> home/js
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:52:34 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-05 13:55:15 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-05 13:55:15 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-05 13:58:30 --> Severity: Notice  --> Undefined variable: link G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-05 13:58:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:09:20 --> Severity: Notice  --> Undefined index:  mid G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 123
ERROR - 2014-12-05 14:22:14 --> 404 Page Not Found --> home/js
ERROR - 2014-12-05 14:51:46 --> Query error: Unknown column 'minfo' in 'field list'
ERROR - 2014-12-05 15:21:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''8,1273'' at line 2
ERROR - 2014-12-05 15:22:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''8,1273'' at line 2
ERROR - 2014-12-05 15:25:45 --> Severity: Notice  --> Array to string conversion G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 54
ERROR - 2014-12-05 15:26:05 --> Severity: Notice  --> Array to string conversion G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 54
ERROR - 2014-12-05 15:27:45 --> Severity: Notice  --> Array to string conversion G:\AppServ\www\sihai5\app\modules\member\controllers\admin_home.php 54
ERROR - 2014-12-05 15:46:44 --> 404 Page Not Found --> home/js
ERROR - 2014-12-05 15:46:44 --> 404 Page Not Found --> home/js
ERROR - 2014-12-05 16:13:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-05 16:13:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-05 16:13:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-05 16:13:18 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-05 16:13:19 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-05 16:13:21 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-05 16:13:21 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-05 16:13:50 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 212
ERROR - 2014-12-05 16:13:50 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 220
ERROR - 2014-12-05 16:13:50 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_add.html 166
ERROR - 2014-12-05 21:31:02 --> 404 Page Not Found --> home/js
ERROR - 2014-12-05 22:19:25 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-05 22:19:26 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-05 22:19:26 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-05 22:19:27 --> 404 Page Not Found --> cate/js
