<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-07 23:57:52 --> Unable to load the requested class: validation
