<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:45 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:47 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:47 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:47 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:47 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:51 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:51 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:51 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:51 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:34:55 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:35:56 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:35:57 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:35:57 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:00 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:01 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:01 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:01 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:01 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:01 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:01 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:03 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:03 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:03 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:03 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:03 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:04 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:04 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:04 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:04 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:04 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:30 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:30 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:31 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:31 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:31 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:31 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:31 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:31 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:32 --> Severity: Warning  --> imagecreatetruecolor() [<a href='function.imagecreatetruecolor'>function.imagecreatetruecolor</a>]: Invalid image dimensions G:\AppServ\www\sihai5\app\libraries\code.php 8
ERROR - 2014-12-04 00:36:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:54 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:56 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:56 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:56 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:56 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:36:56 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:17 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:18 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:18 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:18 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:18 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:37:19 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:25 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:25 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:25 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:25 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:26 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:26 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:26 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:26 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:31 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:38:32 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:52 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:52 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:52 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:52 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:52 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:39:53 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:37 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:37 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:37 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:37 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:37 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:43:38 --> Severity: Warning  --> imagettftext() [<a href='function.imagettftext'>function.imagettftext</a>]: Invalid font filename G:\AppServ\www\sihai5\app\libraries\code.php 31
ERROR - 2014-12-04 00:51:49 --> Severity: Notice  --> Undefined index:  user G:\AppServ\www\sihai5\app\libraries\code.php 63
ERROR - 2014-12-04 00:52:15 --> Severity: Notice  --> Undefined index:  user G:\AppServ\www\sihai5\app\libraries\code.php 63
ERROR - 2014-12-04 00:53:37 --> Severity: Notice  --> Undefined index:  user G:\AppServ\www\sihai5\app\libraries\code.php 63
ERROR - 2014-12-04 00:54:46 --> Severity: Notice  --> Undefined index:  user G:\AppServ\www\sihai5\app\libraries\code.php 64
ERROR - 2014-12-04 00:55:01 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 00:55:03 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-04 00:55:37 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 01:10:06 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 12:07:45 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 12:07:46 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-04 12:07:49 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 12:07:49 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 12:07:52 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 12:07:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-04 12:07:54 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-04 12:08:18 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 12:08:18 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 12:08:18 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 12:08:20 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 12:08:22 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 12:08:23 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 12:08:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 12:08:27 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 19:35:13 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 19:35:25 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-04 19:35:27 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 19:35:27 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 19:35:32 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 19:35:32 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 19:35:37 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 19:35:37 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:35:37 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:35:37 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:37:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 19:37:26 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:37:26 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:37:26 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:37:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:37:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:37:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:39:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:39:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:39:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:39:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:39:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:39:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:41:40 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 19:41:40 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 19:45:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:45:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:45:29 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:45:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:45:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:45:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 19:46:36 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 19:46:36 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 19:46:36 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:25:08 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 20:41:37 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-04 20:42:05 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:42:05 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:42:38 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 20:42:44 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 20:42:44 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 20:42:44 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:42:44 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-04 20:42:45 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 20:42:45 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 20:42:45 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:42:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 20:42:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 20:42:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:43:52 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 20:43:56 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:43:56 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:48:34 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 20:48:43 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 20:50:11 --> 404 Page Not Found --> home/js
ERROR - 2014-12-04 20:50:13 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 20:50:13 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 20:50:13 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:50:22 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:50:22 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:50:27 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 20:50:27 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 20:50:27 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:50:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-04 20:50:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-04 20:50:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-04 20:56:11 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:56:11 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:57:45 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:57:45 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 20:57:48 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 212
ERROR - 2014-12-04 20:57:48 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 220
ERROR - 2014-12-04 20:57:48 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_add.html 166
ERROR - 2014-12-04 21:10:00 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 21:10:00 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-04 21:15:27 --> Severity: Notice  --> Undefined variable: link G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 108
ERROR - 2014-12-04 21:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 108
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 110
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 112
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 121
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 122
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:16:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:20:23 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 115
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  title G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 116
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  pic G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 118
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  url G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 124
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  sort G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 125
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:21:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 128
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:13 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
ERROR - 2014-12-04 21:22:43 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\app\modules\member\views\admin_index.html 113
