<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-06 11:52:24 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 11:53:31 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-06 14:07:08 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 15:30:52 --> Severity: Notice  --> Undefined variable: pd G:\AppServ\www\sihai5\app\modules\member\views\index_login.html 76
ERROR - 2014-12-06 15:57:41 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 15:57:45 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 15:57:46 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 15:57:52 --> Severity: Notice  --> Undefined index:  member G:\AppServ\www\sihai5\app\libraries\code.php 64
ERROR - 2014-12-06 15:59:31 --> Severity: Notice  --> Undefined property: Member_home_module::$session G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 46
ERROR - 2014-12-06 15:59:49 --> Severity: Notice  --> Undefined variable: newdata G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 47
ERROR - 2014-12-06 16:00:13 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:00:13 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:41:58 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:41:59 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:41:59 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:42:19 --> Severity: Notice  --> Undefined index:  username G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 48
ERROR - 2014-12-06 16:44:52 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:45:19 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 16:49:53 --> Severity: Notice  --> Undefined variable: url G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 49
ERROR - 2014-12-06 16:52:24 --> Severity: Notice  --> Undefined variable: url G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 49
ERROR - 2014-12-06 16:55:46 --> Severity: Warning  --> Missing argument 1 for MY_Loader::module(), called in G:\AppServ\www\sihai5\app\modules\member\controllers\home.php on line 51 and defined G:\AppServ\www\sihai5\app\core\MY_Loader.php 101
ERROR - 2014-12-06 16:55:46 --> Severity: Notice  --> Undefined variable: module_uri G:\AppServ\www\sihai5\app\core\MY_Loader.php 103
ERROR - 2014-12-06 17:10:22 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 17:10:23 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 17:13:38 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 17:28:27 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in G:\AppServ\www\sihai5\app\modules\member\controllers\home.php on line 24 and defined G:\AppServ\www\sihai5\system\libraries\Session.php 447
ERROR - 2014-12-06 17:28:27 --> Severity: Notice  --> Undefined variable: item G:\AppServ\www\sihai5\system\libraries\Session.php 449
ERROR - 2014-12-06 17:29:30 --> Severity: Warning  --> Missing argument 1 for MY_Controller::view(), called in G:\AppServ\www\sihai5\app\modules\member\controllers\home.php on line 25 and defined G:\AppServ\www\sihai5\app\core\MY_Controller.php 61
ERROR - 2014-12-06 17:29:30 --> Severity: Notice  --> Undefined variable: fielname G:\AppServ\www\sihai5\app\core\MY_Controller.php 62
ERROR - 2014-12-06 17:49:32 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\views\index\94cms_comm.html.php 16
ERROR - 2014-12-06 17:49:50 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\views\index\94cms_comm.html.php 16
ERROR - 2014-12-06 17:49:51 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\views\index\94cms_comm.html.php 16
ERROR - 2014-12-06 17:50:03 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\views\index\94cms_comm.html.php 16
ERROR - 2014-12-06 17:50:53 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 24
ERROR - 2014-12-06 17:50:54 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 24
ERROR - 2014-12-06 17:51:12 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 24
ERROR - 2014-12-06 17:51:13 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 24
ERROR - 2014-12-06 17:51:13 --> Severity: Notice  --> Undefined variable: _SESSION G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 24
ERROR - 2014-12-06 17:52:06 --> Severity: Notice  --> Undefined property: MY_Loader::$session G:\AppServ\www\sihai5\app\views\index\94cms_comm.html.php 16
ERROR - 2014-12-06 18:06:20 --> 404 Page Not Found --> home/js
ERROR - 2014-12-06 18:06:22 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-06 18:06:38 --> 404 Page Not Found --> admins/js
