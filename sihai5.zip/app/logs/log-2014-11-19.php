<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-19 00:30:41 --> Severity: Notice  --> Undefined index:  time G:\AppServ\www\sihai4\app\views\index\94cms_comm.html.php 21
ERROR - 2014-11-19 00:36:42 --> 404 Page Not Found --> home/js
ERROR - 2014-11-19 00:36:44 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-19 00:36:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-19 00:36:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-19 00:36:47 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-19 00:36:48 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 00:38:28 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 00:39:47 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 11:28:34 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai4\app\views\index\94cms_search.html.php 14
ERROR - 2014-11-19 13:43:54 --> 404 Page Not Found --> home/js
ERROR - 2014-11-19 13:43:55 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-19 13:43:59 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 13:44:00 --> 404 Page Not Found --> mydata/js
ERROR - 2014-11-19 13:44:02 --> 404 Page Not Found --> mydata/js
ERROR - 2014-11-19 13:44:04 --> 404 Page Not Found --> mydata/js
ERROR - 2014-11-19 13:44:04 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 13:44:05 --> 404 Page Not Found --> mydata/js
ERROR - 2014-11-19 13:44:06 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 13:44:07 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai4\app\controllers\admins\content.php 409
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 414
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 422
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai4\app\views\admin\content_updata.html 110
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai4\app\views\admin\content_updata.html 111
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai4\app\views\admin\content_updata.html 115
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 118
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 120
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 122
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai4\app\views\admin\content_updata.html 130
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai4\app\views\admin\content_updata.html 132
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai4\app\views\admin\content_updata.html 136
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai4\app\views\admin\content_updata.html 164
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai4\app\views\admin\content_updata.html 168
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai4\app\views\admin\content_updata.html 172
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai4\app\views\admin\content_updata.html 184
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai4\app\views\admin\content_updata.html 186
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:51:26 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai4\app\controllers\admins\content.php 409
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 414
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 422
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai4\app\views\admin\content_updata.html 110
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai4\app\views\admin\content_updata.html 111
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai4\app\views\admin\content_updata.html 115
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 118
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 120
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 122
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai4\app\views\admin\content_updata.html 130
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai4\app\views\admin\content_updata.html 132
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai4\app\views\admin\content_updata.html 136
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai4\app\views\admin\content_updata.html 164
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai4\app\views\admin\content_updata.html 168
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai4\app\views\admin\content_updata.html 172
ERROR - 2014-11-19 13:51:32 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai4\app\views\admin\content_updata.html 184
ERROR - 2014-11-19 13:51:33 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai4\app\views\admin\content_updata.html 186
ERROR - 2014-11-19 13:51:33 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:51:33 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:51:33 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai4\app\controllers\admins\content.php 409
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 414
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 422
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai4\app\views\admin\content_updata.html 110
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai4\app\views\admin\content_updata.html 111
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai4\app\views\admin\content_updata.html 115
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 118
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 120
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 122
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai4\app\views\admin\content_updata.html 130
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai4\app\views\admin\content_updata.html 132
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai4\app\views\admin\content_updata.html 136
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai4\app\views\admin\content_updata.html 164
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai4\app\views\admin\content_updata.html 168
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai4\app\views\admin\content_updata.html 172
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai4\app\views\admin\content_updata.html 184
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai4\app\views\admin\content_updata.html 186
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 13:53:17 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-19 14:00:30 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-19 14:00:34 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-19 14:00:34 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-19 14:00:34 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-19 14:00:36 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 14:00:38 --> 404 Page Not Found --> mydata/js
ERROR - 2014-11-19 14:00:40 --> 404 Page Not Found --> mydata/js
ERROR - 2014-11-19 14:00:41 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-19 14:00:43 --> 404 Page Not Found --> admins/js
