<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-27 10:48:47 --> 404 Page Not Found --> home/js
ERROR - 2014-12-27 10:48:52 --> 404 Page Not Found --> html/index
ERROR - 2014-12-27 10:49:00 --> 404 Page Not Found --> html/index
ERROR - 2014-12-27 10:50:31 --> 404 Page Not Found --> html/index
ERROR - 2014-12-27 10:50:55 --> 404 Page Not Found --> html/index
ERROR - 2014-12-27 11:16:19 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-27 11:17:06 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 754
ERROR - 2014-12-27 11:19:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at G:\AppServ\www\sihai5\system\core\Exceptions.php:185) G:\AppServ\www\sihai5\system\libraries\Session.php 688
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 765
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 807
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 754
ERROR - 2014-12-27 11:19:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at G:\AppServ\www\sihai5\system\core\Exceptions.php:185) G:\AppServ\www\sihai5\system\libraries\Session.php 688
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 765
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 807
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 754
ERROR - 2014-12-27 11:19:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at G:\AppServ\www\sihai5\system\core\Exceptions.php:185) G:\AppServ\www\sihai5\system\libraries\Session.php 688
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 765
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 807
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 754
ERROR - 2014-12-27 11:19:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at G:\AppServ\www\sihai5\system\core\Exceptions.php:185) G:\AppServ\www\sihai5\system\libraries\Session.php 688
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 765
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:19:31 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 807
ERROR - 2014-12-27 11:20:14 --> 404 Page Not Found --> html/index
ERROR - 2014-12-27 11:22:06 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-27 11:22:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 754
ERROR - 2014-12-27 11:22:15 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 765
ERROR - 2014-12-27 11:22:15 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-27 11:22:15 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:22:15 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 782
ERROR - 2014-12-27 11:22:15 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 807
ERROR - 2014-12-27 11:24:17 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 766
ERROR - 2014-12-27 11:24:17 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 775
ERROR - 2014-12-27 11:24:17 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 783
ERROR - 2014-12-27 11:24:17 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 783
ERROR - 2014-12-27 11:24:17 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 808
ERROR - 2014-12-27 11:24:18 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 766
ERROR - 2014-12-27 11:24:18 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 775
ERROR - 2014-12-27 11:24:18 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 783
ERROR - 2014-12-27 11:24:18 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 783
ERROR - 2014-12-27 11:24:18 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 808
ERROR - 2014-12-27 11:25:29 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 809
ERROR - 2014-12-27 11:27:06 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-27 11:27:08 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-27 11:38:05 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:38:05 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:38:05 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 11:38:09 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:38:09 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:38:09 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 11:42:16 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:42:16 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 11:46:49 --> 404 Page Not Found --> home/js
ERROR - 2014-12-27 11:47:34 --> 404 Page Not Found --> home/js
ERROR - 2014-12-27 11:48:51 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:48:51 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 11:48:55 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:48:55 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 11:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 12:51:50 --> 404 Page Not Found --> home/js
ERROR - 2014-12-27 18:20:20 --> 404 Page Not Found --> home/js
ERROR - 2014-12-27 18:20:22 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:23 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:23 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:23 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
&lt;br /&gt;
HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
&lt;br /&gt;
HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
&lt;br /&gt;
HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Notice  --> Undefined variable: htmlname G:\AppServ\www\sihai5\app\libraries\thtml.php 48
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/index/18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:33 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 67
ERROR - 2014-12-27 18:20:35 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:36 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:36 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:36 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:20:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Notice  --> Undefined variable: htmlname G:\AppServ\www\sihai5\app\libraries\thtml.php 48
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/index/18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 67
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 68
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 69
ERROR - 2014-12-27 18:20:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:41 --> Severity: Notice  --> Undefined variable: htmlname G:\AppServ\www\sihai5\app\libraries\thtml.php 48
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/index/18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 67
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 68
ERROR - 2014-12-27 18:20:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 69
ERROR - 2014-12-27 18:23:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:23:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:23:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:23:33 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:24:34 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/index/18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/index/18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:56 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:24:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:56 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:24:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:56 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:24:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:24:56 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 118
ERROR - 2014-12-27 18:24:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 61
ERROR - 2014-12-27 18:25:52 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:27:20 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:27:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:27:20 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:27:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:27:21 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:27:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:27:21 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:27:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/index/18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:57 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:29:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:57 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:29:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:57 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:29:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:29:57 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:29:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/1/index/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 62
ERROR - 2014-12-27 18:33:34 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:33:55 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 119
ERROR - 2014-12-27 18:34:20 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\libraries\thtml.php 120
ERROR - 2014-12-27 18:35:51 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:35:51 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:35:51 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:35:56 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:35:56 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:35:56 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:35:58 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:35:58 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:35:58 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:36:54 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:36:54 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:36:54 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:38:32 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:38:32 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:38:32 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-27 18:42:07 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:42:07 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:42:59 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:42:59 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:43:01 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:43:01 --> Severity: Notice  --> Undefined variable: pages G:\AppServ\www\sihai5\app\controllers\admins\html.php 41
ERROR - 2014-12-27 18:45:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:39 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:40 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:41 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:42 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:44 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:45 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:46 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:46 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:47 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:47 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:48 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:48 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:49 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:49 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:51 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:52 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:52 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:53 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:53 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:54 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:55 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:56 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:58 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:45:59 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:45:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:00 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:00 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:01 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:02 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:04 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//17.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 45
ERROR - 2014-12-27 18:46:05 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\libraries\thtml.php 46
ERROR - 2014-12-27 18:46:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index//18.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/6/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:37 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:38 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:47:39 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:17 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_6/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/6/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_6/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/17.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/18.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/19.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/20.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/21.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:19 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/22.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/23.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/24.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/25.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/26.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/27.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/28.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:20 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:21 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:22 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/24.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/25.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/26.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/27.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/28.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/29.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:24 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/30.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/31.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/32.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/33.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/34.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/35.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/36.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/37.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/38.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/39.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/40.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/41.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/42.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:26 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/43.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/44.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/45.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/46.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/47.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/48.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:27 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:28 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/49.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:28 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:28 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/3.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/4.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/5.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:54 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/6.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/7.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/8.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/9.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/10.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/11.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/12.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:55 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/13.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/14.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/15.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/5/16.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/6/1.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_6/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/6/2.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_6/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/17.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:56 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/18.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/19.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/20.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/21.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/22.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/23.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/24.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/25.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/26.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/27.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:57 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/28.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:50:59 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:00 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/24.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/25.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/26.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/27.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:01 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/28.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/29.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/30.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/31.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/32.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/33.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:02 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/34.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/35.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/36.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/37.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/38.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/39.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/40.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:03 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/41.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/42.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/43.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/44.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/45.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/46.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:04 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/47.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/48.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/49.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 18:51:05 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 21:52:25 --> 404 Page Not Found --> home/js
ERROR - 2014-12-27 21:52:28 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-27 21:52:28 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-27 21:52:38 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-27 21:52:50 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-27 21:56:05 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:35 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:36 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_5/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_6/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_6/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/17.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/18.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/19.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/20.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/21.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/22.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/23.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:37 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/24.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/25.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/26.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/27.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_10/28.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:38 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:39 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_11/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/2.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/3.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/4.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/5.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/6.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/7.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/8.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/9.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:40 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/11.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/12.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/13.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/14.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/15.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_15/16.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/24.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:41 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/25.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/26.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/27.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/28.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/29.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/30.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:42 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/31.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/32.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/33.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/34.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/35.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/36.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/37.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/38.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/39.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/40.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/41.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/42.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/43.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:44 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/44.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/45.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/46.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/47.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/48.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\\show_view_18/49.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 70
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 71
ERROR - 2014-12-27 22:00:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 72
ERROR - 2014-12-27 22:02:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:02:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 64
ERROR - 2014-12-27 22:09:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:22 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:09:23 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:16 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:17 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:18 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:19 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:40 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:41 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:42 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:43 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:13:44 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:55 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:56 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:57 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:18:59 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:09 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:10 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:11 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:14 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:15 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/24.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/25.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/26.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:28 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/27.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/28.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/29.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/30.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/31.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/32.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/33.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:29 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/34.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/35.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/36.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/37.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/38.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/39.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:30 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/40.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/41.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/42.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/43.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/44.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/45.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:31 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/46.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/47.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/48.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:19:32 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/index.php/show/index/18/49.html) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 65
ERROR - 2014-12-27 22:33:33 --> 404 Page Not Found --> home/js
