<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-12 17:59:31 --> Severity: Warning  --> file_get_contents(http://ip168.com/ip/?ip=127.0.0.1) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 G:\AppServ\www\sihai5\system\core\Common.php 597
ERROR - 2014-12-12 17:59:31 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:05:53 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:05:54 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:07:11 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 599
ERROR - 2014-12-12 18:07:12 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 599
ERROR - 2014-12-12 18:07:12 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 599
ERROR - 2014-12-12 18:07:12 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 599
ERROR - 2014-12-12 18:07:13 --> Severity: Notice  --> Undefined offset:  0 G:\AppServ\www\sihai5\system\core\Common.php 599
ERROR - 2014-12-12 18:16:59 --> Severity: Warning  --> preg_match_all() [<a href='function.preg-match-all'>function.preg-match-all</a>]: Unknown modifier '�' G:\AppServ\www\sihai5\system\core\Common.php 598
ERROR - 2014-12-12 18:17:00 --> Severity: Warning  --> preg_match_all() [<a href='function.preg-match-all'>function.preg-match-all</a>]: Unknown modifier '�' G:\AppServ\www\sihai5\system\core\Common.php 598
ERROR - 2014-12-12 18:17:12 --> Severity: Warning  --> preg_match_all() [<a href='function.preg-match-all'>function.preg-match-all</a>]: Unknown modifier '�' G:\AppServ\www\sihai5\system\core\Common.php 598
ERROR - 2014-12-12 18:17:12 --> Severity: Warning  --> preg_match_all() [<a href='function.preg-match-all'>function.preg-match-all</a>]: Unknown modifier '�' G:\AppServ\www\sihai5\system\core\Common.php 598
ERROR - 2014-12-12 18:17:14 --> Severity: Warning  --> preg_match_all() [<a href='function.preg-match-all'>function.preg-match-all</a>]: Unknown modifier '�' G:\AppServ\www\sihai5\system\core\Common.php 598
ERROR - 2014-12-12 18:22:09 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 595
ERROR - 2014-12-12 18:22:09 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 595
ERROR - 2014-12-12 18:22:09 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 595
ERROR - 2014-12-12 18:22:09 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 595
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:44 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:45 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:45 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:45 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:24:45 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:27:28 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:27:28 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:27:28 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:27:28 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:28:29 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 600
ERROR - 2014-12-12 18:32:23 --> Severity: Notice  --> Trying to get property of non-object G:\AppServ\www\sihai5\system\core\Common.php 601
ERROR - 2014-12-12 18:51:38 --> Severity: Warning  --> Missing argument 1 for getipinfo(), called in G:\AppServ\www\sihai5\app\modules\member\views\index_home.html on line 38 and defined G:\AppServ\www\sihai5\system\core\Common.php 593
ERROR - 2014-12-12 18:56:00 --> Severity: Warning  --> file_get_contents(http://ip.taobao.com/service/getIpInfo.php?ip=127.0.0.1) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.1 502 Bad Gateway
 G:\AppServ\www\sihai5\system\core\Common.php 596
ERROR - 2014-12-12 19:36:54 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 19:36:56 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-12 19:40:03 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 20:57:20 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 20:57:26 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:00:43 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:07 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:07 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:13 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:13 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:13 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:13 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:17 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:17 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:19 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:19 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:22 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:22 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:23 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:23 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:28 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:28 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:32 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:03:32 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:04:16 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:04:16 --> 上传路径无效.
ERROR - 2014-12-12 21:04:30 --> 上传路径无效.
ERROR - 2014-12-12 21:04:35 --> 上传路径无效.
ERROR - 2014-12-12 21:05:11 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:05:17 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:16:45 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:19:36 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:22:23 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:22:32 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:23:09 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:23:25 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:24:15 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:24:17 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:25:17 --> Severity: Notice  --> Undefined index:  file G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 222
ERROR - 2014-12-12 21:29:08 --> 上传路径无效.
ERROR - 2014-12-12 21:29:08 --> 上传路径无效.
ERROR - 2014-12-12 21:29:08 --> 上传路径无效.
ERROR - 2014-12-12 21:29:44 --> 上传路径无效.
ERROR - 2014-12-12 21:29:44 --> 上传路径无效.
ERROR - 2014-12-12 21:29:44 --> 上传路径无效.
ERROR - 2014-12-12 21:31:07 --> 上传路径无效.
ERROR - 2014-12-12 21:31:07 --> 上传路径无效.
ERROR - 2014-12-12 21:31:07 --> 上传路径无效.
ERROR - 2014-12-12 21:34:35 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:34:35 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:34:35 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:38:58 --> Severity: Warning  --> move_uploaded_file(upload/php_avatar1_20141212213858_643_6G6DK62I.jpg) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:38:58 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'C:\Windows\Temp\php8817.tmp' to 'upload/php_avatar1_20141212213858_643_6G6DK62I.jpg' G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:38:58 --> Severity: Warning  --> move_uploaded_file(upload/php_avatar1_20141212213858_646_6WIH6L8B.jpg) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:38:58 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'C:\Windows\Temp\php8818.tmp' to 'upload/php_avatar1_20141212213858_646_6WIH6L8B.jpg' G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:38:58 --> Severity: Warning  --> move_uploaded_file(upload/php_avatar1_20141212213858_648_9O2Z6C2O.jpg) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:38:58 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'C:\Windows\Temp\php8829.tmp' to 'upload/php_avatar1_20141212213858_648_9O2Z6C2O.jpg' G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:39:01 --> Severity: Warning  --> move_uploaded_file(upload/php_avatar1_20141212213901_120_LDAQBTM4.jpg) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:39:01 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'C:\Windows\Temp\php91EA.tmp' to 'upload/php_avatar1_20141212213901_120_LDAQBTM4.jpg' G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:39:01 --> Severity: Warning  --> move_uploaded_file(upload/php_avatar1_20141212213901_124_LHT9M5RX.jpg) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:39:01 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'C:\Windows\Temp\php91EB.tmp' to 'upload/php_avatar1_20141212213901_124_LHT9M5RX.jpg' G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:39:01 --> Severity: Warning  --> move_uploaded_file(upload/php_avatar1_20141212213901_126_MBQTUC6Q.jpg) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:39:01 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'C:\Windows\Temp\php91EC.tmp' to 'upload/php_avatar1_20141212213901_126_MBQTUC6Q.jpg' G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 254
ERROR - 2014-12-12 21:44:51 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:44:51 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:44:51 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:45:00 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:45:00 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:45:00 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:46:03 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:46:03 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:46:03 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:48:19 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:48:19 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:48:19 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:50:36 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:50:36 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:50:36 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:04 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:04 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:04 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:05 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:05 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:05 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:06 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:06 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:06 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:06 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:06 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:06 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:07 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:07 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:07 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:09 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:09 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:09 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:14 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:14 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:51:14 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:52:09 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:52:18 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:52:53 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:52:56 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:53:51 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:55:07 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:55:07 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:55:07 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 21:55:50 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:55:50 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:55:50 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:56:57 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:56:57 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:56:57 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:58:54 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:58:54 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 21:58:54 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 22:01:12 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 22:01:12 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 22:01:12 --> 您没有选择要上传的文件.
ERROR - 2014-12-12 22:01:37 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:01:37 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:01:37 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:04:12 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:04:12 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:04:12 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:04:49 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:04:49 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:04:49 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:05:31 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:05:31 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:05:31 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:07:03 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:07:03 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:07:03 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:07:34 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:07:34 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:07:34 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:09:56 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:09:56 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:09:56 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:11:19 --> Severity: Notice  --> Undefined variable: mimes G:\AppServ\www\sihai5\system\core\Output.php 107
ERROR - 2014-12-12 22:11:19 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:11:19 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:11:19 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:12:28 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:12:28 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:12:28 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:13:05 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:13:05 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:13:05 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:14:13 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:14:13 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:14:13 --> 此文件的类型在禁止上传之列.
ERROR - 2014-12-12 22:37:50 --> Severity: Warning  --> unlink(G:\AppServ\www\sihai5\/uploads/member/tx/tx_1_20141212223637_661_7SVQULVZ.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 282
ERROR - 2014-12-12 22:37:50 --> Severity: Warning  --> unlink(G:\AppServ\www\sihai5\/uploads/member/tx/tx_1_20141212223637_663_GXFLVTXP.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 282
ERROR - 2014-12-12 22:37:50 --> Severity: Warning  --> unlink(G:\AppServ\www\sihai5\/uploads/member/tx/tx_1_20141212223637_665_V1HCYC67.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 282
ERROR - 2014-12-12 22:38:40 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-12 22:38:51 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-12 22:40:50 --> Severity: Warning  --> unlink(G:\AppServ\www\sihai5\/uploads/member/tx/tx_1_20141212223758_559_BU5FBSRF.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 282
ERROR - 2014-12-12 22:40:50 --> Severity: Warning  --> unlink(G:\AppServ\www\sihai5\/uploads/member/tx/tx_1_20141212223758_561_6MFP344O.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 282
ERROR - 2014-12-12 22:40:50 --> Severity: Warning  --> unlink(G:\AppServ\www\sihai5\/uploads/member/tx/tx_1_20141212223758_563_L9SEJ2PT.jpg) [<a href='function.unlink'>function.unlink</a>]: No such file or directory G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 282
ERROR - 2014-12-12 22:45:32 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 66
ERROR - 2014-12-12 22:47:15 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 66
ERROR - 2014-12-12 22:47:23 --> Severity: Notice  --> Undefined index:  tx G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 67
ERROR - 2014-12-12 22:48:46 --> Severity: Notice  --> Undefined index:  1 G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 66
ERROR - 2014-12-12 22:50:27 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in G:\AppServ\www\sihai5\app\modules\member\controllers\login.php on line 69 and defined G:\AppServ\www\sihai5\system\libraries\Session.php 447
ERROR - 2014-12-12 22:50:27 --> Severity: Notice  --> Undefined variable: item G:\AppServ\www\sihai5\system\libraries\Session.php 449
ERROR - 2014-12-12 22:55:08 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 22:55:21 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 23:47:22 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 23:51:04 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 23:51:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-12 23:51:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-12 23:51:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-12 23:51:18 --> 404 Page Not Found --> home/js
ERROR - 2014-12-12 23:51:32 --> 404 Page Not Found --> home/js
