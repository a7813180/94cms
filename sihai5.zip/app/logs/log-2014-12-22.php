<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-22 20:18:47 --> 404 Page Not Found --> home/js
ERROR - 2014-12-22 20:18:55 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-22 20:18:55 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-22 20:41:16 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-22 20:41:16 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-22 20:41:16 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-22 20:41:19 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-22 20:41:21 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-22 21:18:04 --> 404 Page Not Found --> home/js
