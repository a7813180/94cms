<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-29 00:18:07 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 17:19:02 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:19:02 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 26
ERROR - 2014-12-29 17:19:10 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:19:10 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 26
ERROR - 2014-12-29 17:19:18 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:19:18 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 26
ERROR - 2014-12-29 17:19:24 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:19:26 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:19:27 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:19:27 --> Severity: Notice  --> Undefined index:  0 G:\AppServ\www\sihai5\app\modules\member\views\index_home.html 26
ERROR - 2014-12-29 17:21:05 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:21:06 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:21:08 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:21:09 --> Severity: Notice  --> Undefined index:  2 G:\AppServ\www\sihai5\app\modules\member\views\index_top.html 16
ERROR - 2014-12-29 17:21:32 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 17:21:34 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 17:21:34 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 17:22:00 --> 404 Page Not Found --> html/index
ERROR - 2014-12-29 17:24:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-29 17:24:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-29 17:24:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-29 21:15:55 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 21:15:56 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-29 21:15:58 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 21:15:58 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:16:22 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:16:43 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:31:27 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 21:31:30 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:31:57 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:03 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai5\app\controllers\admins\content.php 409
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 414
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\controllers\admins\content.php 422
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\app\views\admin\content_updata.html 102
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\views\admin\content_updata.html 110
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai5\app\views\admin\content_updata.html 111
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai5\app\views\admin\content_updata.html 115
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 118
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 120
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai5\app\views\admin\content_updata.html 122
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai5\app\views\admin\content_updata.html 130
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai5\app\views\admin\content_updata.html 132
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai5\app\views\admin\content_updata.html 136
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai5\app\views\admin\content_updata.html 164
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\views\admin\content_updata.html 168
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai5\app\views\admin\content_updata.html 172
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai5\app\views\admin\content_updata.html 184
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai5\app\views\admin\content_updata.html 186
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:32:33 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai5\app\views\admin\content_updata.html 191
ERROR - 2014-12-29 21:38:37 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:38:37 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:38:37 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:38:51 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:38:51 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:38:51 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:39:42 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:39:51 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:39:56 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:41:14 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:41:28 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:41:30 --> 404 Page Not Found --> html/css
ERROR - 2014-12-29 21:41:30 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:41:36 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 21:41:43 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 21:41:45 --> 404 Page Not Found --> html/css
ERROR - 2014-12-29 21:41:45 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:41:45 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:41:45 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:42:45 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 21:42:45 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 21:43:37 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:46:32 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:46:34 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:46:41 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:46:42 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:46:49 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:46:52 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:46:58 --> 404 Page Not Found --> html/content_list.php
ERROR - 2014-12-29 21:47:15 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:47:16 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:47:22 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:47:35 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:47:36 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:47:38 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:49:25 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:49:26 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:49:49 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:50:08 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:50:25 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 21:51:03 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:51:04 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:51:04 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:51:04 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:51:23 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:51:24 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:51:31 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 21:51:31 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 21:52:05 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:52:36 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:52:37 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:52:46 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:53:26 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:53:27 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:53:27 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:22 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:22 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:23 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:24 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:24 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:24 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:25 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:27 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:54:50 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 21:57:56 --> 404 Page Not Found --> html/images
ERROR - 2014-12-29 22:02:18 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 22:03:24 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:03:25 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:03:25 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:03:30 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:15:44 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 22:17:15 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:22:37 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:22:47 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 22:22:47 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 22:23:00 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 22:23:00 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 22:26:05 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:27:01 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:27:03 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:27:04 --> 404 Page Not Found --> html/makehtml_archives_action.php
ERROR - 2014-12-29 22:28:09 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 22:29:53 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\html_cate.html 36
ERROR - 2014-12-29 22:29:53 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\html_cate.html 36
ERROR - 2014-12-29 22:29:57 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\html_cate.html 36
ERROR - 2014-12-29 22:29:57 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\html_cate.html 36
ERROR - 2014-12-29 22:30:51 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\html_cate.html 40
ERROR - 2014-12-29 22:30:51 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\html_cate.html 40
ERROR - 2014-12-29 22:30:51 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\html_cate.html 40
ERROR - 2014-12-29 22:30:51 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\html_cate.html 40
ERROR - 2014-12-29 22:30:53 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai5\app\views\admin\html_cate.html 40
ERROR - 2014-12-29 22:30:53 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\html_cate.html 40
ERROR - 2014-12-29 22:45:51 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\news\list_33.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 73
ERROR - 2014-12-29 22:45:51 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 74
ERROR - 2014-12-29 22:45:51 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 75
ERROR - 2014-12-29 23:02:42 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 23:06:33 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 23:06:33 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 23:06:34 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-29 23:16:50 --> 404 Page Not Found --> home/js
ERROR - 2014-12-29 23:17:36 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 23:17:36 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 23:18:09 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-29 23:19:01 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 23:19:01 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-29 23:19:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 20
ERROR - 2014-12-29 23:19:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 131
ERROR - 2014-12-29 23:19:07 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\views\admin\plugs.html 135
ERROR - 2014-12-29 23:19:08 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-29 23:19:08 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-29 23:38:17 --> Could not find the language line "profiler_session_data"
ERROR - 2014-12-29 23:41:12 --> Could not find the language line "profiler_session_data"
ERROR - 2014-12-29 23:44:43 --> Could not find the language line "profiler_session_data"
