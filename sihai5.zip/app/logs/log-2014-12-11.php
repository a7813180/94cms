<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-11 15:59:17 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\views\index_pay.html 23
ERROR - 2014-12-11 15:59:17 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_pay.html 25
ERROR - 2014-12-11 16:00:04 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_pay.html 25
ERROR - 2014-12-11 16:03:56 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_pay.html 25
ERROR - 2014-12-11 16:04:07 --> Severity: Notice  --> Undefined variable: userid G:\AppServ\www\sihai5\app\modules\member\views\index_pay.html 25
ERROR - 2014-12-11 18:40:32 --> Severity: Notice  --> Undefined variable: dep G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 34
ERROR - 2014-12-11 18:40:32 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 34
ERROR - 2014-12-11 18:40:32 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:41:19 --> Severity: Notice  --> Undefined variable: pay_data G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 34
ERROR - 2014-12-11 18:41:19 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 34
ERROR - 2014-12-11 18:41:19 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:42:01 --> Severity: Notice  --> Undefined variable: myts G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 150
ERROR - 2014-12-11 18:42:01 --> Severity: Notice  --> Undefined variable: dqys G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 150
ERROR - 2014-12-11 18:42:01 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai5\app\modules\member\controllers\home.php 150
ERROR - 2014-12-11 18:42:01 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:45:13 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:45:28 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:45:38 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:45:39 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:45:45 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:47:04 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:47:24 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:47:47 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:48:36 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:48:37 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:48:48 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:49:23 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:49:24 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:49:24 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:49:37 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 18:50:12 --> Severity: Notice  --> Undefined variable: page G:\AppServ\www\sihai5\app\modules\member\views\index_pay_data.html 47
ERROR - 2014-12-11 19:09:19 --> 404 Page Not Found --> home/js
ERROR - 2014-12-11 19:19:44 --> Severity: Notice  --> Undefined index:  pid G:\AppServ\www\sihai5\app\modules\member\controllers\login.php 77
ERROR - 2014-12-11 19:20:48 --> 404 Page Not Found --> home/js
ERROR - 2014-12-11 19:20:55 --> 404 Page Not Found --> home/js
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 5
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 21
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: money G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 22
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: jifen G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 22
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: bili G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 22
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: money G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 22
ERROR - 2014-12-11 19:26:55 --> Severity: Notice  --> Undefined variable: bili G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 26
ERROR - 2014-12-11 19:27:25 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 5
ERROR - 2014-12-11 19:29:25 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 5
ERROR - 2014-12-11 19:29:44 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 5
ERROR - 2014-12-11 19:30:02 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai5\app\modules\member\views\index_yaoqing.html 5
ERROR - 2014-12-11 20:25:50 --> 404 Page Not Found --> home/js
