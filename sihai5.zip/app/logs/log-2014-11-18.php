<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-11-18 13:51:21 --> 404 Page Not Found --> home/js
ERROR - 2014-11-18 13:51:22 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 13:53:24 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 13:53:27 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 13:54:02 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 13:54:41 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 13:54:45 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 13:54:45 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 13:54:45 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 13:54:45 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 13:54:45 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 14:00:57 --> Severity: Notice  --> Undefined variable: cate G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 79
ERROR - 2014-11-18 14:15:40 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 14:15:40 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 14:15:52 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 14:15:58 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined variable: catename G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 6
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined variable: catekey G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 7
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined variable: catedes G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 8
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai4\system\core\Common.php 748
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai4\system\core\Common.php 753
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\system\core\Common.php 779
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 34
ERROR - 2014-11-18 14:16:19 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 38
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai4\system\core\Common.php 748
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai4\system\core\Common.php 753
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\system\core\Common.php 779
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 32
ERROR - 2014-11-18 14:17:03 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 36
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai4\system\core\Common.php 748
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai4\system\core\Common.php 753
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\system\core\Common.php 779
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 32
ERROR - 2014-11-18 14:17:05 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 36
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai4\system\core\Common.php 748
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai4\system\core\Common.php 753
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai4\system\core\Common.php 757
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\system\core\Common.php 779
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 32
ERROR - 2014-11-18 14:17:25 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 36
ERROR - 2014-11-18 14:17:48 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 32
ERROR - 2014-11-18 14:17:48 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 36
ERROR - 2014-11-18 14:18:00 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 32
ERROR - 2014-11-18 14:18:00 --> Severity: Notice  --> Uninitialized string offset:  0 G:\AppServ\www\sihai4\app\views\index\94cms_gbook.html.php 36
ERROR - 2014-11-18 14:39:16 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 14:39:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 14:39:21 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:39:21 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:39:21 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:39:22 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:39:22 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:39:22 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:39:22 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:39:23 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:39:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:39:36 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:39:36 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:39:36 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:44:20 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:44:37 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:44:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:44:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:44:40 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:45:20 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:45:26 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:45:26 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:45:26 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:45:57 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:45:57 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:45:57 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:45:58 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:46:15 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:47:15 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:47:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:47:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:47:17 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:47:17 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:47:18 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:47:18 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:47:18 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:47:33 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:48:12 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:48:26 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:49:19 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:49:23 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:49:26 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:50:48 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:50:53 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:51:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:52:17 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\model_add.html 24
ERROR - 2014-11-18 14:52:17 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 24
ERROR - 2014-11-18 14:52:19 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\model_add.html 24
ERROR - 2014-11-18 14:52:19 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 24
ERROR - 2014-11-18 14:53:13 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 24
ERROR - 2014-11-18 14:54:06 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:54:10 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 14:54:10 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 14:54:10 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 14:54:27 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 14:57:13 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 14:57:13 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 14:57:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-11-18 14:57:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-11-18 14:57:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-11-18 14:57:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-11-18 14:57:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-11-18 14:57:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-11-18 14:58:05 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 14:58:15 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:58:17 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:58:42 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 14:59:05 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 14:59:13 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:04:11 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_add.html 156
ERROR - 2014-11-18 15:04:11 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_add.html 156
ERROR - 2014-11-18 15:05:00 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_add.html 156
ERROR - 2014-11-18 15:05:00 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_add.html 156
ERROR - 2014-11-18 15:05:00 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_add.html 163
ERROR - 2014-11-18 15:12:29 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:12:29 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:12:31 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:12:31 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:12:35 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:12:35 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:12:36 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:12:52 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:15:05 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:15:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 15:15:05 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 15:15:05 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 15:15:05 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:15:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:15:07 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 15:15:07 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 15:15:07 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 15:15:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:15:08 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:15:09 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 15:15:09 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 15:15:09 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 15:15:09 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:15:55 --> 404 Page Not Found --> home/js
ERROR - 2014-11-18 15:15:56 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:16:56 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:16:56 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 15:16:56 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 15:16:56 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 15:16:56 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 15:17:05 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:17:21 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:17:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 15:17:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 15:17:32 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 15:17:34 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:17:35 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 15:17:35 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 15:17:35 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 15:18:08 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:18:21 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 15:18:21 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 15:18:21 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 15:18:22 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:30:16 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:30:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai4\app\controllers\admins\content.php 409
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai4\app\views\admin\content_updata.html 110
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai4\app\views\admin\content_updata.html 111
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai4\app\views\admin\content_updata.html 115
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 118
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 120
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 122
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai4\app\views\admin\content_updata.html 130
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai4\app\views\admin\content_updata.html 132
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai4\app\views\admin\content_updata.html 136
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 141
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 141
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 141
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 141
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 141
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai4\app\views\admin\content_updata.html 164
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai4\app\views\admin\content_updata.html 168
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai4\app\views\admin\content_updata.html 172
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai4\app\views\admin\content_updata.html 184
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai4\app\views\admin\content_updata.html 186
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 15:30:27 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 15:30:30 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:30:33 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 15:30:33 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 15:30:33 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 15:30:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:30:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:32:45 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:32:45 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:32:55 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:32:55 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:32:55 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:32:55 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:33:37 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:33:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:33:37 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:33:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:33:38 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:33:39 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:33:39 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:33:39 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:33:39 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:33:58 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:33:59 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:33:59 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:33:59 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:33:59 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:34:06 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:34:07 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:34:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:34:07 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:34:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:34:15 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:34:16 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 64
ERROR - 2014-11-18 15:34:16 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\model_add.html 77
ERROR - 2014-11-18 15:37:42 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:38:30 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:38:33 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:39:50 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:39:56 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:41:54 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:42:07 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:42:08 --> Query error: Unknown column '94_cate.template_category' in 'field list'
ERROR - 2014-11-18 15:42:23 --> 404 Page Not Found --> home/js
ERROR - 2014-11-18 15:42:24 --> Query error: Unknown column '94_cate.template_category' in 'field list'
ERROR - 2014-11-18 15:44:22 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:48:03 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:48:09 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 108
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 109
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 108
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 109
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 108
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 109
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 108
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 109
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 108
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 109
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 108
ERROR - 2014-11-18 15:50:29 --> Severity: Notice  --> Undefined index:  template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_add.html 109
ERROR - 2014-11-18 15:52:59 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:53:38 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:53:43 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:53:46 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:54:01 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:54:08 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:58:03 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:58:03 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:58:03 --> Severity: Notice  --> Undefined variable: template_list_wap G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 204
ERROR - 2014-11-18 15:58:03 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 204
ERROR - 2014-11-18 15:58:03 --> Severity: Notice  --> Undefined variable: template_show_wap G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 213
ERROR - 2014-11-18 15:58:03 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 213
ERROR - 2014-11-18 15:58:47 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:59:31 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 15:59:33 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:59:33 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:59:38 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:59:39 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:59:39 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:59:44 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 15:59:45 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 15:59:45 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:00:32 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:00:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:00:36 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:00:38 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 16:00:38 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 16:00:38 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 16:00:40 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:00:46 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:00:52 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:05:31 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:05:37 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:05:46 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:09:19 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:09:27 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:09:31 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:09:38 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:09:45 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:10:54 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 16:10:54 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 16:10:55 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:11:06 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:11:08 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:11:08 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:11:43 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:11:44 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:11:44 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:11:51 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:12:10 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:12:12 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:12 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:15 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:17 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:17 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:21 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:23 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:23 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:25 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:26 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:26 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:29 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:30 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:38 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:40 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:40 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:46 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:48 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:48 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:53 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:12:55 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:12:55 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:02 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:04 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:06 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:13:07 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:11 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:14 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:19 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:21 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:21 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:27 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:30 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:30 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:37 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:42 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:43 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:43 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:49 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:52 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:52 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:57 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:13:59 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:13:59 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:14:04 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:14:08 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:14:08 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:15:14 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:17:24 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:17:24 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:18:10 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:18:10 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:18:10 --> Severity: Notice  --> Undefined index:  template_lis G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 184
ERROR - 2014-11-18 16:18:10 --> Severity: Notice  --> Undefined index:  template_lis G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 184
ERROR - 2014-11-18 16:18:22 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:18:22 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:19:50 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:19:50 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:24:37 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:25:37 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:25:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:26:28 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:27:24 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:27:24 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:27:41 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:27:41 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:28:10 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:28:10 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:28:44 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:28:44 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:28:50 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:28:55 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:28:58 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:28:58 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:29:00 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:29:00 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:50:01 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:51:48 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 16:51:51 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:51:51 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:53:55 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:53:57 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:53:57 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:54:09 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:54:09 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:54:12 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:54:16 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:54:16 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:54:20 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:54:20 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 16:55:16 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 16:55:57 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 17:11:42 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 17:11:44 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 17:11:44 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 17:12:57 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 17:12:57 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 17:13:04 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 17:13:11 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 17:13:14 --> Severity: Notice  --> Undefined variable: template_index G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 17:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\cate_updata.html 172
ERROR - 2014-11-18 17:15:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:00:24 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:03:23 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:03:35 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:03:35 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:05:37 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 18:05:37 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 18:05:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 18:05:38 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 18:05:38 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 18:05:38 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 18:05:38 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_add.html 264
ERROR - 2014-11-18 18:06:36 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 212
ERROR - 2014-11-18 18:06:36 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 220
ERROR - 2014-11-18 18:06:36 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_add.html 166
ERROR - 2014-11-18 18:18:43 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:24:03 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:24:18 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:29:37 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:32:15 --> Severity: Notice  --> Undefined index:  tongbu_temp G:\AppServ\www\sihai4\app\controllers\admins\cate.php 148
ERROR - 2014-11-18 18:32:21 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:37:21 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:37:27 --> Severity: Notice  --> Undefined index:  tongbu_temp G:\AppServ\www\sihai4\app\controllers\admins\cate.php 148
ERROR - 2014-11-18 18:37:33 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:37:56 --> Severity: Notice  --> Undefined index:  tongbu_temp G:\AppServ\www\sihai4\app\controllers\admins\cate.php 148
ERROR - 2014-11-18 18:38:01 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:38:39 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:38:45 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:11 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:15 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:18 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:21 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:29 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:33 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:38 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:44 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:39:48 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:40:00 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:40:03 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:40:34 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 18:40:34 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai4\app\views\admin\content_page.html 138
ERROR - 2014-11-18 18:40:41 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 18:40:41 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 18:40:41 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 18:40:42 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 18:40:42 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 18:40:42 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 18:40:42 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:40:43 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:40:44 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:40:52 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:41:04 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:41:12 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:41:34 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:41:40 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:41:44 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:41:46 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 18:41:46 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 18:41:46 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 18:41:48 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:41:53 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:42:14 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:44:41 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:44:57 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:45:39 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:45:49 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:45:49 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:46:04 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:46:14 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:46:17 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:46:19 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:46:30 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:47:24 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:47:26 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:47:44 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:48:05 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:48:32 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 18:48:41 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 18:48:45 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 19:36:13 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 20
ERROR - 2014-11-18 19:36:13 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 131
ERROR - 2014-11-18 19:36:13 --> Severity: Notice  --> Undefined variable: mid G:\AppServ\www\sihai4\app\views\admin\plugs.html 135
ERROR - 2014-11-18 19:36:13 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 19:36:31 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 19:36:34 --> 404 Page Not Found --> admins/js
ERROR - 2014-11-18 20:16:52 --> 404 Page Not Found --> cate/js
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined index:  cid G:\AppServ\www\sihai4\app\controllers\admins\content.php 409
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 414
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai4\app\controllers\admins\content.php 422
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai4\app\views\admin\content_updata.html 102
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: title G:\AppServ\www\sihai4\app\views\admin\content_updata.html 110
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: color G:\AppServ\www\sihai4\app\views\admin\content_updata.html 111
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: shorttitle G:\AppServ\www\sihai4\app\views\admin\content_updata.html 115
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 118
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 120
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: flag G:\AppServ\www\sihai4\app\views\admin\content_updata.html 122
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: keywords G:\AppServ\www\sihai4\app\views\admin\content_updata.html 130
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: author G:\AppServ\www\sihai4\app\views\admin\content_updata.html 132
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: litpic G:\AppServ\www\sihai4\app\views\admin\content_updata.html 136
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: description G:\AppServ\www\sihai4\app\views\admin\content_updata.html 164
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai4\app\views\admin\content_updata.html 168
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: publishtime G:\AppServ\www\sihai4\app\views\admin\content_updata.html 172
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: click G:\AppServ\www\sihai4\app\views\admin\content_updata.html 184
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: sort G:\AppServ\www\sihai4\app\views\admin\content_updata.html 186
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 20:29:29 --> Severity: Notice  --> Undefined variable: template_show G:\AppServ\www\sihai4\app\views\admin\content_updata.html 191
ERROR - 2014-11-18 21:00:13 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai4\app\views\index\94cms_tag.html.php 14
ERROR - 2014-11-18 23:19:13 --> Severity: Notice  --> Use of undefined constant reur - assumed 'reur' G:\AppServ\www\sihai4\app\controllers\show.php 128
ERROR - 2014-11-18 23:19:17 --> Severity: Notice  --> Use of undefined constant reur - assumed 'reur' G:\AppServ\www\sihai4\app\controllers\show.php 128
ERROR - 2014-11-18 23:19:38 --> Severity: Notice  --> Use of undefined constant teur - assumed 'teur' G:\AppServ\www\sihai4\app\controllers\show.php 128
ERROR - 2014-11-18 23:45:34 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai4\app\views\index\94cms_show_news.html.php 72
ERROR - 2014-11-18 23:45:42 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai4\app\views\index\94cms_show_news.html.php 72
ERROR - 2014-11-18 23:51:04 --> Severity: Notice  --> Undefined property: module_tag::$db G:\AppServ\www\sihai4\app\libraries\module_tag.php 42
