<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-13 00:00:06 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 00:13:40 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 00:49:56 --> Unable to load the requested class: thtml
ERROR - 2014-12-13 00:49:56 --> 404 Page Not Found --> admins/js
ERROR - 2014-12-13 00:56:46 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\controllers\admins\html.php 16
ERROR - 2014-12-13 00:56:46 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\controllers\admins\html.php 18
ERROR - 2014-12-13 00:56:57 --> Severity: Notice  --> Undefined variable: content G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 00:59:17 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\controllers\admins\html.php 15
ERROR - 2014-12-13 01:00:17 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\\html\cate_10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 9
ERROR - 2014-12-13 01:00:17 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 10
ERROR - 2014-12-13 01:00:17 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 11
ERROR - 2014-12-13 01:00:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\html\cate_10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 9
ERROR - 2014-12-13 01:00:29 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 10
ERROR - 2014-12-13 01:00:29 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 11
ERROR - 2014-12-13 01:02:58 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\htmls\cate_10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 9
ERROR - 2014-12-13 01:02:58 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 10
ERROR - 2014-12-13 01:02:58 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 11
ERROR - 2014-12-13 01:03:25 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\htmls\cate_10.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 9
ERROR - 2014-12-13 01:03:25 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 10
ERROR - 2014-12-13 01:03:25 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 11
ERROR - 2014-12-13 01:08:31 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 01:16:18 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 01:20:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/1.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-13 01:20:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/2.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-13 01:20:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/3.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-13 01:20:36 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/4.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 8
ERROR - 2014-12-13 01:27:56 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 01:27:56 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 01:27:58 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/danpianmoxing.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:29:45 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/danpianmoxing.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/danpianmoxing.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:20 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/news.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:20 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/dataz.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 12
ERROR - 2014-12-13 01:30:21 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:30:21 --> Severity: Notice  --> Undefined variable: id G:\AppServ\www\sihai5\app\libraries\thtml.php 19
ERROR - 2014-12-13 01:31:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/danpianmoxing.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:12 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/2.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/3.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/4.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/news.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:13 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/dataz.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/danpianmoxing.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/2.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/3.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/4.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/news.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:31:35 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/dataz.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:34:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/news.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:34:50 --> Severity: Warning  --> file_get_contents(http://94cms.host.tcncn.com/cate/index/dataz.shtml) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: HTTP request failed! HTTP/1.0 500 Internal Server Error
 G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news\list_view_5_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 16
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 17
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 28
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\dataz\list_view_6_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 16
ERROR - 2014-12-13 01:43:45 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 17
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news\list_view_5_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 16
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 17
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> mkdir() [<a href='function.mkdir'>function.mkdir</a>]: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 31
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\dataz\list_view_6_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\app\libraries\thtml.php 15
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> fputs(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 16
ERROR - 2014-12-13 01:56:52 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource G:\AppServ\www\sihai5\app\libraries\thtml.php 17
ERROR - 2014-12-13 02:00:17 --> Severity: Notice  --> Undefined property: tHtml::$load G:\AppServ\www\sihai5\app\libraries\thtml.php 13
ERROR - 2014-12-13 02:01:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\dataz) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:20 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:01:21 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: Invalid argument G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:02:49 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news\list_view_5_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\dataz\list_view_6_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_7_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_8_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_9_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_10_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:29 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_11_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_12_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_13_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_14_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_15_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_16_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_17_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:30 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\\list_view_18_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:03:53 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news\list_view_5_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:04:15 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\news\list_view_5_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:04:15 --> Severity: Warning  --> fopen(G:\AppServ\www\sihai5\a\dataz\list_view_6_1.html) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: No such file or directory G:\AppServ\www\sihai5\system\helpers\file_helper.php 90
ERROR - 2014-12-13 02:10:03 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 19:26:24 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 22:29:38 --> 404 Page Not Found --> home/js
ERROR - 2014-12-13 22:29:39 --> 404 Page Not Found --> cate/js
ERROR - 2014-12-13 23:20:02 --> Severity: Notice  --> Undefined variable: md G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-13 23:20:02 --> Severity: Warning  --> Invalid argument supplied for foreach() G:\AppServ\www\sihai5\app\views\admin\content_page.html 138
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: catename G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 6
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: catekey G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 7
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: catedes G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 8
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 16
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: tcid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 23
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  type G:\AppServ\www\sihai5\system\core\Common.php 765
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  ename G:\AppServ\www\sihai5\system\core\Common.php 770
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  id G:\AppServ\www\sihai5\system\core\Common.php 774
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  name G:\AppServ\www\sihai5\system\core\Common.php 796
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: tcid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 24
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 26
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: catename G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 34
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: cid G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 58
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined variable: pagenum G:\AppServ\www\sihai5\app\views\index\94cms_list_news.html.php 58
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  modelid G:\AppServ\www\sihai5\app\libraries\content_tag.php 49
ERROR - 2014-12-13 23:24:28 --> Severity: Notice  --> Undefined index:  tablename G:\AppServ\www\sihai5\app\libraries\content_tag.php 52
ERROR - 2014-12-13 23:24:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LEFT JOIN `94_cate` ON `94_`.`cid`=`94_cate`.`id`
WHERE `94_`.`status` =  0
AND ' at line 2
ERROR - 2014-12-13 23:30:57 --> 404 Page Not Found --> admins/%7BPUBLIC%7Dstyle
ERROR - 2014-12-13 23:30:57 --> 404 Page Not Found --> admins/%7BPUBLIC%7Djs
ERROR - 2014-12-13 23:49:01 --> Severity: Notice  --> Array to string conversion G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:49:42 --> Severity: Notice  --> Array to string conversion G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:51:02 --> Severity: Notice  --> Array to string conversion G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:51:22 --> Severity: Warning  --> preg_match_all() expects parameter 2 to be string, array given G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:51:43 --> Severity: Warning  --> preg_match_all() expects parameter 2 to be string, array given G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:52:14 --> Severity: Warning  --> preg_match_all() expects parameter 2 to be string, array given G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:53:10 --> Severity: Warning  --> preg_match_all() expects parameter 2 to be string, array given G:\AppServ\www\sihai5\app\controllers\admins\html.php 19
ERROR - 2014-12-13 23:58:42 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Notice  --> Undefined variable: arr G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
ERROR - 2014-12-13 23:58:42 --> Severity: Warning  --> in_array() [<a href='function.in-array'>function.in-array</a>]: Wrong datatype for second argument G:\AppServ\www\sihai5\app\controllers\admins\html.php 21
