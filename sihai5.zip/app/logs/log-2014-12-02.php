<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-02 23:57:01 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_tag.html.php 14
ERROR - 2014-12-02 23:57:12 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_tag.html.php 14
ERROR - 2014-12-02 23:57:15 --> Severity: Notice  --> Undefined variable: data G:\AppServ\www\sihai5\app\views\index\94cms_tag.html.php 14
