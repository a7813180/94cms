<?php
header('location:index.php/admins/login');
?>